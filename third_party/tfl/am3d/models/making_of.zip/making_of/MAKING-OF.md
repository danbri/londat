# Making of: Canada Water and Canary Wharf station boxes in Blender via MCP (2026-10-05)

## This version (run 2, 5-second captures)

The owner asked for the making-of again with a capture every 5 s (run 1 used 10 s). Run 2 is a replay: the same
step scripts as run 1, run again in order through the same MCP tool (`execute_blender_code`) by `scripts/replay.sh`,
in a new Blender session. The script waits 12 s after each step, so each step shows in two or three captures, and
then saves the nine stills with the MCP `look` tool. `steps.log` gives the time of each step.

- Run 1 (10 s captures, 17:44 to 18:01 UTC) was the authoring session: the steps were written, run and corrected
  then. Its 102 captures are in the earlier version of this zip in the londat git history (commit 0077caa).
- Run 2 (5 s captures, 19:45 to 19:51 UTC) shows the finished steps only, at the speed of the script. It does not
  show the reading, planning and corrections of run 1.
- The geometry of run 2 is the same as run 1: the same triangle counts (Canary Wharf 55,348; Canada Water 46,728)
  and 0.000 m maximum vertex difference in the STL files. Only the triangle order in the files changed.

## Tools

- Blender 4.0.2 (Ubuntu package `blender`, 88 MB download) running with its GUI under Xvfb (`:99`, 1600 x 1000),
  software OpenGL (Mesa llvmpipe, `LIBGL_ALWAYS_SOFTWARE=1`).
- blender-mcp: PyPI `blender-mcp` 2.0.0 is now a wrapper that installs `mcp-for-blender` 2.1.8 (Siddharth Ahuja,
  MIT licence). Its Blender add-on (`blender_mcp/bundled/addon.py`) was installed as a user add-on, enabled at
  start-up, and auto-starts a socket server on localhost:9876. Telemetry is off by default in the add-on and was
  also disabled in the server with `DISABLE_TELEMETRY=1`. The add-on needs `python3-requests` for Blender's
  system Python 3.12.
- All modelling went THROUGH the MCP: `mcp_call.py` starts the `mcp-for-blender` server over stdio (the official
  `mcp` Python client) and calls its tools: `execute_blender_code` (every build step), `get_scene_info`, and `look`
  (viewport screenshots: the stills). The server exposes: get_addon_status, disable_telemetry, get_scene_info,
  execute_blender_code, record_trajectory_feedback, look, generate_3d, search_assets, import_asset. No asset
  search or generation was used.
- Screen captures: a shell loop (`scripts/shotloop5.sh`) saves the Xvfb screen every 5 s with ImageMagick
  `import -window root` (1280 x 800 JPEG, quality 60). 68 captures from 19:45:06 to 19:50:48 UTC.
- usd-core 26.8 for the USD file (the Blender build has no USD exporter). ffmpeg (timelapse, 2 frames a second, so
  5 s of work = 0.5 s) and ImageMagick montage (contact sheet).

## Steps (each is a file in `scripts/steps/`, run by `scripts/step.sh` through the MCP)

1. Read the sheets, the 3D page skill and data, facts.json and sourced-levels.json.
2. `extract-osm.mjs`: decode the page's data (`under.js` indoor ways and points, `area.js` tracks, tunnels and
   buildings) within 200 to 260 m of each station into one JSON; `plan-svg.mjs` plots it (`plans/`).
3. Escalator directions: from `indoor.js` (oriented network edges) at Canary Wharf; at Canada Water (outside the
   indoor.js box) from the levels of the ways that touch each end. Both methods agreed where they overlap with a
   hand check.
4. `00-setup`: clear the scene, collections, materials by class.
5. Canary Wharf `10`-`15`: box, street plane, tracks and tunnel stubs; OSM platforms; hall (OSM floors + published
   volume) and mezzanine; ESC 1-20 and the B1 stair; lifts, stairs C and D, canopies A, B, B1, entrances; labels.
6. Canada Water `20`-`24`: Jubilee box and ELL slot; platforms, tracks, tunnels; OSM hall, ELL-level concourse,
   glass drum fitted to the OSM arc; 8 OSM escalators + 4 middle ones, 22 OSM stair flights; lifts 1-4, escape
   stair 3, entrances, labels.
7. `30-check` (every object has `uncertainty`; counts), `31` origins to geometry and georeferenced axis empties,
   tour views (stills), `40` save and export, `41` + `to_usd.py` USD.

## Judgements (where the data did not decide)

- Platform floor = rail level + 1.0 m at both stations.
- Canada Water ELL platform level: Wikipedia 11 m (-5.6 m OD) chosen over the sheet's 8.0 m (-2.6), because the 3D
  page uses it and the 13 m slot fits it. JL: TfL FOI rail level chosen over the sheet (15.0 m) and Wikipedia (22 m).
- Box placement: published lengths placed along the OSM track axis. Canary Wharf west end 4 m beyond the OSM Plaza
  canopy; the published hall (222.79 m) from just west of the OSM hall to beyond the top of ESC 9. Canada Water JL
  box centred on the OSM platforms; ELL slot centred on the track crossing, width tapering 22 to 15 m.
- Hall and mezzanine floor levels (Canary Wharf -3.1 and 3.0; Canada Water 0.9).
- Escalator counts: Canary Wharf OSM has 9 lines for ESC 1-9 (agrees with the sheet), 3 for ESC 15-17 (agrees),
  2 + 1 at B and B1; the Plaza has 4 OSM lines where the sheet numbers 5 (ESC 10-14): 5 modelled over the OSM span.
  Canada Water: the sheet draws banks of 3, OSM maps 2 lines per bank: a third escalator added between each pair.
- Naming: OSM calls the eastern Canary Wharf entrance "Fosterito Entrance"; the sheet writes "Fosterito entrance
  (central area)" at B. The model keeps the OSM positions and both labels. The sheet label at B read as ESC 18,19.
- Lift positions from the sheet at Canada Water (all four) and shaft sizes everywhere; Canary Wharf lift positions
  are OSM elevator nodes. Escape stairs (Canary Wharf C and D, Canada Water escape stair 3): sheet only.
- Canopies: simple half-ellipsoid glass shells. A and B footprints and heights (7 m, 4 m) from OSM buildings; B1
  size judged. Canada Water drum height 7.6 m above the street judged; diameter 25 m published.
- ELL platforms 3 and 4: 120 x 4 m side platforms outside the OSM tracks (judged); which is northbound is judged.
- Tunnel stubs held at the station rail level for 60 to 90 m (no gradient).

## What failed or needed a work-around

- `blender-mcp` on PyPI is now a rename wrapper; it pulled `mcp-for-blender`. The add-on failed first (no
  `requests` in Blender's Python 3.12): fixed with `apt-get install python3-requests`.
- `pkill -f "blender --python"` killed the calling shell (the pattern matched its own command line); Blender was
  restarted with `setsid nohup`.
- The splash screen stayed up until it was clicked away with `xdotool`.
- No USD in the Debian Blender build: USD written with pxr outside Blender. No Draco in the glTF exporter (an
  error line, harmless: no compression asked).
- The OSM data has no ELL platform outlines at Canada Water and no lifts at Canada Water: those are judged.
