#!/bin/bash
# usage: step.sh steps/NN-name.py  -> runs lib + step inside Blender through the MCP execute_blender_code tool
W=/tmp/claude-0/-home-user/4f8e0432-4626-58f7-ae94-a02a29442cb5/scratchpad/blender-agent/work
f=$W/.code-$$.py
printf 'exec(open("%s/stations_lib.py").read())\nexec(open("%s").read())\n' "$W" "$(realpath $1)" > $f
python3 $W/mcp_call.py execute_blender_code @$f 2>>$W/mcp.log; rc=$?; rm -f $f; exit $rc
