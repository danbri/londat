TOUR_VIEW = "cw-below"
exec(open(WORK + "/steps/tour.py").read())
