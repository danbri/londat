TOUR_VIEW = "cwf-escalators"
exec(open(WORK + "/steps/tour.py").read())
