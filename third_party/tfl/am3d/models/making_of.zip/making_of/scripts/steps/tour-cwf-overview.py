TOUR_VIEW = "cwf-overview"
exec(open(WORK + "/steps/tour.py").read())
