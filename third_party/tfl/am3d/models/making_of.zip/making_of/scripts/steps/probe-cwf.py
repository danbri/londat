st = "canary-wharf"
L = [l["pts"] for l in OSM["stations"][st]["lines"] if l["k"] == "subway" and len(l["pts"]) > 30 and l["pts"][0][0] > -20]
L = [[p for p in l if -20 <= p[0] <= 320] for l in L]
c, u = axis_fit(L)
print("axis c", [round(x,1) for x in c], "u", [round(x,4) for x in u], "deg", round(math.degrees(math.atan2(u[1],u[0])),2))
for l in L: print("track t at s=0..", [round(sv(c,u,p)[1],1) for p in l[::8]])
for f in osm(st, kind="steps"): 
    a, b = sv(c,u,f["pts"][0]), sv(c,u,f["pts"][-1]); print("steps", f["lv"], [round(x,1) for x in a], [round(x,1) for x in b])
for f in osm(st, closed=True):
    ss = [sv(c,u,p) for p in f["pts"]]; print(f["kind"], f["lv"], f.get("name"), "s", round(min(x[0] for x in ss),1), round(max(x[0] for x in ss),1), "t", round(min(x[1] for x in ss),1), round(max(x[1] for x in ss),1))
for p in OSM["stations"][st]["pois"]:
    if p["kind"] in ("entrance","station"): print("poi", p.get("name"), [round(x,1) for x in sv(c,u,(p["x"],p["z"]))], p["g"])
for b in OSM["stations"][st]["buildings"]:
    ss=[sv(c,u,p) for p in b["pts"]]; print("bldg h", b["h"], "b", b["b"], "s", round(min(x[0] for x in ss),1), round(max(x[0] for x in ss),1), "t", round(min(x[1] for x in ss),1), round(max(x[1] for x in ss),1))
