TOUR_VIEW = "cwf-east-B-B1"
exec(open(WORK + "/steps/tour.py").read())
