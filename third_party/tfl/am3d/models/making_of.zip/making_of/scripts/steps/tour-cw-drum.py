TOUR_VIEW = "cw-drum"
exec(open(WORK + "/steps/tour.py").read())
