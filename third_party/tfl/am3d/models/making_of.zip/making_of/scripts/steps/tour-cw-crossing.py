TOUR_VIEW = "cw-crossing"
exec(open(WORK + "/steps/tour.py").read())
