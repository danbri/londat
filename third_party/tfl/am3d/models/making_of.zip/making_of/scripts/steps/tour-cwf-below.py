TOUR_VIEW = "cwf-below"
exec(open(WORK + "/steps/tour.py").read())
