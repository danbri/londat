TOUR_VIEW = "cw-overview"
exec(open(WORK + "/steps/tour.py").read())
