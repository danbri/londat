TOUR_VIEW = "cwf-west-plaza"
exec(open(WORK + "/steps/tour.py").read())
