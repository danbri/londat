#!/bin/bash
# Rebuilds both stations in the running Blender through the MCP, with a 5 s screen capture loop.
set -e
W=/tmp/claude-0/-home-user/4f8e0432-4626-58f7-ae94-a02a29442cb5/scratchpad/blender-agent/work
R=${1:?rundir}; SHOTS=$R/shots; STILLS=$R/stills; mkdir -p $SHOTS $STILLS; rm -f $SHOTS/.stop
cd $W
log() { echo "$(date -u +%H:%M:%S) $*" | tee -a $R/steps.log; }
setsid nohup $W/shotloop5.sh $SHOTS > /dev/null 2>&1 < /dev/null &
sleep 6
for s in 00-setup 10-cwf-box 11-cwf-west-tunnels-platforms 12-cwf-hall 13-cwf-escalators 14-cwf-lifts-stairs-canopies 15-cwf-labels \
         20-cw-boxes 21-cw-platforms-tracks 22-cw-hall-drum 23-cw-escalators-stairs 24-cw-lifts-labels 30-check 31-origins-empties; do
  log "step $s"; ./step.sh steps/$s.py > $R/out-$s.txt; sleep 12
done
for v in cwf-overview cwf-west-plaza cwf-escalators cwf-east-B-B1 cwf-below cw-overview cw-crossing cw-drum cw-below; do
  log "view $v"; ./step.sh steps/tour-$v.py > /dev/null; sleep 4
  python3 mcp_call.py look '{}' --png $STILLS/$v.png >> $R/look.txt 2>>$W/mcp.log; sleep 6
done
log "step 40-save-export"; ./step.sh steps/40-save-export.py > $R/out-40.txt; sleep 6
log "step 41-dump-for-usd"; ./step.sh steps/41-dump-for-usd.py > $R/out-41.txt
python3 to_usd.py $W/usd-dump.json $W/out/stations.usdc > $R/out-usd.txt
sleep 6; touch $SHOTS/.stop; log "done"
